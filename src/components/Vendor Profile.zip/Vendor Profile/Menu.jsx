import { Outlet } from "react-router-dom";

const Menu = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Menu;
