const MessageContainer = () => {
  return (
    <div className="w-full h-full flex">
      {/* Left Side */}
      <div className="bg-red-500 w-[25%] h-full">
        <h1>Hello</h1>
      </div>
      {/* Right Side */}
      <div className="bg-yellow-500 w-[75%] h-full">
        <h1>Hello</h1>
      </div>
    </div>
  );
};

export default MessageContainer;
